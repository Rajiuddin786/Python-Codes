y=input("What is the answer to the Great Question of Life, the Universe and Everything ").strip().title()
if y=="42" or y=="Fourty-Two" or y=="Forty Two" or y="forty-two" :
    print("Yes")
else:
    print("No")