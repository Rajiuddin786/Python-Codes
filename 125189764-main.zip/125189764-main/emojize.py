import emoji
em = input("Input: ")
print(emoji.emojize(em))